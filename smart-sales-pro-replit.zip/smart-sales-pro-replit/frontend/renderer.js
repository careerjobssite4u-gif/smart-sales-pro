// frontend/renderer.js (simple demo client for hosted API)
const API = (location.origin) ? location.origin + '/api' : 'http://localhost:3000/api';

const btnLogin = document.getElementById('btnLogin');
const btnLogout = document.getElementById('btnLogout');
const itemsDiv = document.getElementById('items');
const loginDiv = document.getElementById('login');

btnLogin.addEventListener('click', async () => {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const res = await fetch(API + '/auth/login', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ username, password })
  });
  const data = await res.json();
  if (res.ok) {
    localStorage.setItem('ss_token', data.token);
    loginDiv.style.display = 'none';
    itemsDiv.style.display = 'block';
    loadItems();
  } else {
    alert(data.error || 'Login failed');
  }
});

btnLogout.addEventListener('click', () => {
  localStorage.removeItem('ss_token');
  loginDiv.style.display = 'block';
  itemsDiv.style.display = 'none';
});

async function loadItems() {
  const token = localStorage.getItem('ss_token');
  const res = await fetch(API + '/items', { headers: { 'Authorization': 'Bearer ' + token } });
  if (!res.ok) { alert('Failed to load items'); return; }
  const items = await res.json();
  const list = document.getElementById('itemsList');
  list.innerHTML = '';
  items.forEach(it => {
    const li = document.createElement('li');
    li.textContent = `${it.name} — stock: ${it.stock} — price: ${it.sell_price}`;
    list.appendChild(li);
  });
}
