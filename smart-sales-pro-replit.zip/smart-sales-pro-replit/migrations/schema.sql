-- MySQL schema for SmartSales Pro (minimal)
CREATE DATABASE IF NOT EXISTS smart_sales;
USE smart_sales;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(200),
  role ENUM('admin','cashier','viewer') DEFAULT 'cashier',
  is_active TINYINT(1) DEFAULT 1,
  expiry_date DATE NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sku VARCHAR(100) UNIQUE,
  name VARCHAR(255) NOT NULL,
  category_id INT,
  buy_price DECIMAL(12,2) DEFAULT 0,
  sell_price DECIMAL(12,2) DEFAULT 0,
  per_item_percentage DECIMAL(5,2) DEFAULT 0,
  stock INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Seed admin user (password: admin123) - change in production
INSERT INTO users (username, password_hash, full_name, role) VALUES
('admin', '$2b$10$wzQwN6rFQG0gM0zGmQ8G9u5Q2l6u2jQjYV8w3uT9e1p0mYx3Yd1eG', 'Administrator', 'admin')
ON DUPLICATE KEY UPDATE username = username;

-- Note: the above hash is for 'admin123' using bcrypt salt 10. Regenerate for production.
