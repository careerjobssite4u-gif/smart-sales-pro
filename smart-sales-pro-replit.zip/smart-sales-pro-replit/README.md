# SmartSales Pro — Replit/Render Ready Starter

This repo is prepared to run on platforms like Replit or Render. It serves both API and frontend from a single Node.js app.

## Quick start (local)
1. Create a MySQL database and run `migrations/schema.sql` to create tables.
2. Create a `.env` in backend/ with:

DB_HOST=localhost
DB_USER=root
DB_PASS=
DB_NAME=smart_sales
PORT=3000
JWT_SECRET=change_this

3. Install dependencies and start:

```
npm install
npm start
```

## Deploy to Replit
- Create a new Repl (Node.js), upload this project, then run `npm start`.

## Deploy to Render
- Create a new Web Service, connect to GitHub repo, set build/start command: `npm install && npm start`.

